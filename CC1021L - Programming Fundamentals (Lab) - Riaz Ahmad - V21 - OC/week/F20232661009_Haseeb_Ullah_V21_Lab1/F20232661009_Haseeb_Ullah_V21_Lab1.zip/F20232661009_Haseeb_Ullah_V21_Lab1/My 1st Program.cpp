#include <iostream>

using namespace std;

int main()
{
    /*
    cout << "Hello world!" << endl;
    cout << "Haseeb Ullah" << endl;

    int number1=100;
    int number2=105;
    int sum=0;

    sum=number1+number2; // sum of NO 1 and sum NO 2
    cout<< "Number 1 is: "<<number1<<endl;
    cout <<"Number 2 is: "<< number2<<endl;
    cout <<"Sum is " <<sum<<endl;
    cout <<  << endl; */


    string name ;
    string father;
    string age;

    cout<<"Whats Your Name?"<<endl; // asking name

    cin>>name;

    cout<<"Enter Your Father Name?"<<endl;  // asking Father name

    cin>>father;

    cout<<"Whats Your Age?"<<endl; // asking age
    
    cin>>age;



    cout<<"Name is: "<<name<< endl;

    cout<<"Father Name is: "<<father<<endl;
    
    cout<<"Age is :  "<<age<<endl;






/* how to ask NAME
              AGE
              Father Name
              College
              University
              */




    return 0;
}
