#include <iostream>

using namespace std;

int main()
{
    string name;
    string id;
    string course;

    cout<< "Whats is your Name: \n";
    cin>>name;
    cout<< "Whats is your ID: \n";
    cin>>id;
    cout<< "Whats is your Course name: \n";
    cin>>course;

    cout<< "Your name: "<<name<< "\n" ;
    cout<< "Your ID: "<<id<< "\n" ;
    cout<< "Your Course name: "<<course<<"\n";

    return 0;
}
