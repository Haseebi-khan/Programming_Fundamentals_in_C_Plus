#include <iostream>

using namespace std;

int main()
{
    cout << "* * * * * * * * * \n"<<endl;

    cout << "* \t\t  *\n"<<endl;
    cout << "* \t\t  *\n"<<endl;

    cout << "* * * * * * * * * \n"<<endl;


    return 0;
}
