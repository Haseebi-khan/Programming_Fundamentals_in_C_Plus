#include <iostream>

using namespace std;

int main()
{
    float pi;
    float area;
    int r;
    r = 3;
    pi = 3.14;

    area = pi * r * r;
    cout<< "Where,   Radius = 3"<<endl;

    cout<< "Area = Pi * r^2"<<endl;

    cout<< "Area ="<<area;
}
