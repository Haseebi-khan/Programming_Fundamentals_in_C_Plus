#include <iostream>

using namespace std;

int main()
{
    // this is single line comment
    /*this is multiple line comment*/


    cout << "Hello World! " << endl;// this line print hello world

    cout << "\n" << endl;


    cout << "*" << endl;
    cout << "* *" << endl;
    cout << "* * *" << endl;
    cout << "* * * *" << endl;


    cout<<endl;


    cout << "1\t2\t3\t4\t5" << endl;
    cout << "6\t7\t8\t9\t0" << endl;


    cout << "Pakistan\tis\tmy\tcountry \n";
    cout << "Pakistan\tis\tits\tcapital";


    cout<< "\n";
    cout<< "\n";cout<< "\n";cout<< "\n\n\n";



    int number;
    cout<< "Enter a Father Number";
    cin>>number;
    cout<< "Your Father number is:  "<<number<< "\n\n\n" ;



    /*int num1, num2, sum;
    cout<< "Enter a number:";
    cin>>num1;
    cout<< "Enter another number:";
    cin>>num2;
    sum = num1 + num2;
    cout<< "Sum:  "<<sum<< "\n";*/


    int num1, num2, sum;
    cout<< "Enter two number:";
    cin>>num1>>num2;
    sum = num1 + num2;
    cout<<num1<<"+"<<num2<<"="<<sum<<"\n";
    cout<<"3+2 ="<<3+2<<"\n";
    cout<<3<<"+"<<2<<"="<<3+2<<"\n";







    return 0;
}
